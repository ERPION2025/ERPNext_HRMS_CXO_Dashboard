# HR Analytics

Native ERPNext/HRMS dashboards for Recruitment, Onboarding, Probation & Confirmation,
Leave, and Appraisal, plus an Executive roll-up — built as a normal Frappe app so the
data never leaves your site and every screen sits behind your existing Desk permissions.
Exit/offboarding is intentionally not included in this version.

## What's in here

- **Dashboard Screen** / **Dashboard Widget** doctypes — the config engine. Every
  chart, scorecard and table on every screen is a `Dashboard Widget` record: doctype,
  filters, group-by field, aggregate, chart type, and an `is_active` flag. Untick
  `is_active` to hide a widget without deleting it — same for whole screens via
  `Dashboard Screen`. Both are Frappe doctypes, so creating a new widget is just
  filling in a form, no deploy required.
- **`hr_analytics/api/widgets.py`** — the generic engine that reads a `Dashboard
  Widget` record and returns its data, either via the generic group-by/aggregate
  builder or by calling a custom whitelisted method (`api_override`) for aggregations
  the generic builder can't express (budget-chain joins, leave liability, etc).
- **`hr_analytics/api/workflow.py`** — introspects the real `Workflow` doctype and
  its `Workflow Document State` children for whatever doctype you point it at, so the
  approval-stage timelines always show your actual states, never guessed ones. Used
  for Job Requisition, Job Applicant (`custom_recruitment_status`), Leave
  Application, Mid-Year Review, and Annual Performance Review.
- **`hr_analytics/api/{recruitment,onboarding,probation,leave,appraisal,executive}.py`**
  — the module-specific aggregations built against your custom fields.
- **`hr_analytics/install.py`** — seeds six screens and ~35 pre-built widgets on
  install (`after_install` hook), so you land with a full dashboard and hide what you
  don't want rather than building from zero.
- **`hr_analytics/page/hr_dashboard`** + **`public/js/dashboard_core.js`** — the
  Desk page at `/app/hr-dashboard`: sidebar per screen, a company/date-range filter
  bar, and dependency-free bar/donut/timeline/table renderers (no external chart
  library — everything is plain CSS/SVG, so nothing calls out to the internet).

## Install

```bash
cd ~/frappe-bench
bench get-app hr_analytics /path/to/hr_analytics   # or your git remote once you push it
bench --site <your-site> install-app hr_analytics
```

Reinstalling widgets after editing `install.py` (e.g. you fixed a fieldname):

```bash
bench --site <your-site> execute hr_analytics.install.create_widgets
```

It's idempotent — existing widgets with the same name are left alone.

## Before you rely on these numbers — three things in your schema to fix first

1. **`Job Requisition.custom_approved_budget` / `custom_consumed_budget` /
   `custom_remaining_budget` are typed Data, not Currency.** The budget-utilization
   widgets `sum()` them — that only works reliably on a numeric field type. Switch
   them to Currency (or Float) via Customize Form.
2. **No `custom_confirmation_date` field on Employee.** "Confirmed this month"
   currently falls back to the record's `modified` timestamp, which over-counts any
   Employee edited for unrelated reasons. Add a real confirmation-date field, set it
   from the Probation Review workflow's Confirmed transition, and swap it into
   `api/probation.py::get_confirmed_this_month_count`.
3. **`Mid-Year Review` / `Annual Performance Review` employee-link fieldnames are
   unconfirmed.** Your fields export only showed their `workflow_state`
   customization, not their full schema, so `DOCTYPE_EMPLOYEE_FIELD` in
   `api/appraisal.py` is a placeholder. The two "completion by department" widgets
   ship with `is_active = 0` for that reason — confirm the fieldname, update the map,
   then switch them on.

## Adding a chart from the UI

Desk → HR Analytics → Dashboard Widget → New. Pick the screen, doctype, group-by
field and chart type; save. It's live on that screen immediately — no restart, no
deploy. This is the same mechanism the seeded widgets use.
